package TCPport;

import gnu.io.*;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Enumeration;
import java.util.TooManyListenersException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JOptionPane;


import org.omg.stub.java.rmi._Remote_Stub;

import Cricket.Data;
import Cricket_App.AppWindow;

public class Client extends Thread  {

	private BufferedWriter _out;
	
	private OutputStream _outSerial;
	private InputStream _input;
	
	
	private SerialPortEvent _event;
	
	private Socket _skt;
	
	private BufferedReader _in;
	private int _DB;
	private String _retezec;
	private String _serialPort;
	
	private Separace _separace = new Separace();
	private ReadSerial _readThread;
	private WriteSerial _writeThread;
	private SerialPort port = null;
	
	
	
	public Client (String jmeno, String serial) {
		// TODO Auto-generated constructor stub
		super(jmeno);
		_serialPort=serial;
		
		
	}
	
	@Override
	public void run() {
		Serial_connect();
		//TCP_connect();
	}
	
   private void Close_port() {
		
		if (_input != null)
		{
			try {
				_input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(_outSerial != null)
		{
			try {
				_outSerial.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(_outSerial != null) port.close();
}
	
	private void Serial_connect(){
		String wantedPortName = _serialPort;
		Enumeration portIdentifiers = CommPortIdentifier.getPortIdentifiers();
		
		CommPortIdentifier portId = null;  // will be set if port found
		while (portIdentifiers.hasMoreElements())
		{
		    CommPortIdentifier pid = (CommPortIdentifier) portIdentifiers.nextElement();
		    if(pid.getPortType() == CommPortIdentifier.PORT_SERIAL &&
		       pid.getName().equals(wantedPortName)) 
		    {
		        portId = pid;
		        break;
		    }
		}
		if(portId == null)
		{
			JOptionPane.showMessageDialog(new JFrame("Error"),
				    "Spatne zvoleny port "+_serialPort );
		    System.err.println("Could not find serial port " + wantedPortName);
		    //System.exit(1);
		}
		
		
		try {
		    port = (SerialPort) portId.open(
		        wantedPortName, // Name of the application asking for the port 
		        10000   // Wait max. 10 sec. to acquire port
		    );
		} catch(PortInUseException e) {
		    System.err.println("Port already in use: " + e);
		    JOptionPane.showMessageDialog(new JFrame("Error"),
				    "Port already in use: " + _serialPort );
		}
		
		
		try {
			port.setSerialPortParams(
				    115200,
				    SerialPort.DATABITS_8,
				    SerialPort.STOPBITS_1,
				    SerialPort.PARITY_NONE);
		} catch (UnsupportedCommOperationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}
		
		_input = null;
		try {
			_input = port.getInputStream();
		 	_outSerial= port.getOutputStream();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 System.err.println("Can't open input stream: write-only");
			  _input = null;
			  _outSerial = null;
			  Close_port();
		}
		
		_writeThread = new WriteSerial("Vlakno_Zapis", _outSerial);
		_writeThread.start();
		
		try {
			port.addEventListener(new ReadSerial(_input));
		} catch (TooManyListenersException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			Close_port();
		}
		port.notifyOnDataAvailable(true);
		
			while (_input != null)
			{
			
			}
		
			Close_port();
		
		
	}
	
	private void TCP_connect() {
		try {
			_skt = new Socket("127.0.0.1", 2947);

			System.out.println("Client Connected");
			_out = new BufferedWriter(new OutputStreamWriter(
					_skt.getOutputStream()));
			_in = new BufferedReader(new InputStreamReader(
					_skt.getInputStream()));
			// Smycka

			_out.write("r" + "\n");
			_out.flush();

			while ((_retezec = _in.readLine()) != null) {

				System.out.println(_retezec);

				_DB = _separace.get_DB(_retezec);

			}

			_in.close();
			_skt.close();
			System.out.println("Input ukoncen");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Nepripojeno");
		}
	}
	
}
