package TCPport;

import java.io.IOException;
import java.io.OutputStream;

public class WriteSerial extends Thread {
	private OutputStream _out;
	
	public WriteSerial(String jmeno, OutputStream _outSerial) {
		// TODO Auto-generated constructor stub
		super(jmeno);
		_out = _outSerial;
	}
	public void run() {
		try {
			String text = "r" + "\n";
			_out.write(text.getBytes());
			_out.flush();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Odeslan retezec");
	}
}
