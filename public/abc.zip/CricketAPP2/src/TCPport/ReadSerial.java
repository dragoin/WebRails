package TCPport;

import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Objects;
import java.util.Vector;

import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import Cricket.Cricket;
import Cricket.Data;
import Cricket.Koordinace;
import Cricket.Main;
import Cricket.WCL;
import Cricket_App.AppWindow;

public class ReadSerial implements SerialPortEventListener{
	private InputStream _input;
	private BufferedReader _inputbuffer;
	private String _retezec = "null";
	private String _ID;
	private Cricket _cricket;
	
	private double _vzdalenost;
	
	
	private DefaultTableModel _model;
	
	
	private Separace _separ= new Separace();
	private WCL _wcl;
	private int i = 0; 

	
	public ReadSerial(InputStream input) {
		// TODO Auto-generated constructor stub
		
				_input = input;
				
		
		_inputbuffer = new BufferedReader(new InputStreamReader(_input));
		}
	
	public void serialEvent(SerialPortEvent event) {
        // do your event handler stuff here
		 switch (event.getEventType()) {
	        case SerialPortEvent.DATA_AVAILABLE:
			try {
				_retezec =_inputbuffer.readLine();
				
				//System.out.println(_retezec);
				
				_vzdalenost = _separ.get_DB(_retezec);
				_ID = _separ.get_ID(_retezec);
				
				
				
				//_cricket = new Cricket(_ID, _vzdalenost, 1);
			
				
				_wcl = new WCL();
			
				if (_ID != null) {
				synchronized (Main.class) {
					//Main.data.set_List_Cricketu(_cricket);
					Main.data.get_List_Cricketu(_ID).addPacket(_vzdalenost);
					
					System.out.println(Main.data.get_List_Cricketu(_ID).get_name() + " >>  " + _vzdalenost  + "  "+Main.data.get_List_Cricketu(_ID).get_seznamDat().size() );
					Main.data.zmeneno();
				}					
				}
							
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Chyba prijaty prazdny paket");
				//e.printStackTrace();
			}
			
	            break;
	        }
	    }

}
