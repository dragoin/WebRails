package TCPport;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Separace {
	public int get_DB(String Data) {

		int DB_int = 0;
		int prumer = 0;
		String DB_string = "0";// musi mit hodnotu jinak parseInt hodi chybu

		Pattern o = Pattern.compile("(DB=)(\\d{1,3})");
		Matcher n = o.matcher(Data);

		while (n.find()) {
			//System.out.println("Found a " + n.group() + ".");
			DB_string = n.group(2);
			//System.out.println(DB_string);

		}

		DB_int = Integer.parseInt(DB_string);
		prumer += Integer.parseInt(DB_string);
		//System.out.println("Hodnota Vzdalenosti>> " + prumer);
		return DB_int;

	}
	public String get_ID(String data_ID) {
		Pattern p = Pattern
		.compile("(ID=)(\\w{2}:\\w{2}:\\w{2}:\\w{2}:\\w{2}:\\w{2}:\\w{2}:\\w{2})");

		Matcher m = p.matcher(data_ID);

		String data = null;

		while (m.find()) {
		//System.out.println("Found a " + m.group() + ".");

		data = m.group(2);

		}
		return data;
		}
}
