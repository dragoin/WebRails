package Cricket_App;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.SwingUtilities;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import Cricket.Cricket;
import Cricket.Data;
import Cricket.Main;

public class TableData extends AbstractTableModel {

	private List <Integer> ids;
	private int _countColumn;
	private int _countRaw;
	
	
	
	private String[] columnNames = {"First Name",
             "Last Name",
             "Sport",
             "# of Years",
             "Vegetarian"};
	
	private Object[][] data = {
			{"Kate", "Smith",
			"Snowboarding", new Integer(5), new Boolean(false)}};
	
	public TableData() {
		// TODO Auto-generated constructor stub
		synchronized (Main.class) {
	
			data[0][1]= Main.data.get_XYsouradnice().get_x();
		}
	}
	@Override
	public void addTableModelListener(TableModelListener l) {
		// TODO Auto-generated method stub

	}

	@Override
	public Class getColumnClass(int columnIndex) {
		// TODO Auto-generated method stub
		return getValueAt(0, columnIndex).getClass();
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columnNames.length;
	}

	@Override
	public String getColumnName(int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return data.length;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return data[rowIndex][columnIndex];
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		 if (columnIndex == 0 || columnIndex == 1)
		   {
		        return false;
		   }
		   else
		   {
			return true;
		   }
	}

	@Override
	public void removeTableModelListener(TableModelListener l) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setValueAt(Object value, int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		data[rowIndex][columnIndex] = value;
        fireTableCellUpdated(rowIndex, columnIndex);
        fireTableDataChanged();
	}
	public void addColumn(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setData()
	{
		synchronized ( Main.class) {
			
			
			
		}
		
	}
	
}
