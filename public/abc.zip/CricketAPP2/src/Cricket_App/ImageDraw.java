package Cricket_App;



import java.awt.AlphaComposite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;

public class ImageDraw extends JComponent{

	private BufferedImage _img; 
	private double _scale=1;
	private double _opacity=1;
	private double _rotation = 0;

	public ImageDraw(BufferedImage img ) {
		// TODO Auto-generated constructor stub
		_img = img;
		
		repaint();
	}
	
	public void setScale(double scale) {
		_scale = scale/100;
		
		repaint();
	}
	public void setRotate(double rotation) {
		_rotation =rotation;
		repaint();
	}
	
public void setOpacity(double opacity){
	_opacity= opacity/100;
	System.out.println(_opacity);
	repaint();
	}
	
	@Override
public void paintComponent(Graphics g) {
	super.paintComponent(g);
	Graphics2D g2 = (Graphics2D)g;
	 AlphaComposite ac = java.awt.AlphaComposite.getInstance(AlphaComposite.SRC_OVER,(float)_opacity);
	 g2.rotate(Math.toRadians(_rotation),300, 300);
     g2.setComposite(ac);
     g2.drawImage(_img, AffineTransform.getScaleInstance(_scale,_scale), null);
}

}
