package Cricket_App;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.geom.Point2D;

import javax.swing.JPanel;

public class VykresCricketu extends JPanel{

	
	private double _scaleVykresu = 1;
	
	public VykresCricketu() {
		// TODO Auto-generated constructor stub
		
	}
	 
	public void prekresli(double Scale){
		
		_scaleVykresu = Scale;
		repaint();
	}
	
	@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        int okraj = 30; 
        
         Graphics2D g2d = (Graphics2D) g;
         /*  
         g.drawString("X", 20, 20);
         g.setColor(Color.red);
         g.fillOval(100, 100, 5, 5);
         
       
         Point pt1 = new Point(50,50);
         Point pt2 = new Point(100,150);
         GradientPaint grad = new GradientPaint(pt1 , Color.black, pt2, Color.GREEN);
         g2d.setPaint(grad);
         
         g2d.fillOval(50, 50, 150, 200);
         g.setColor(new Color(150,150,150));
      g.fillOval(150, 150, 20, 20);
           */ 
         
         g.setColor(Color.BLACK);
         g2d.drawLine(okraj, okraj, okraj , getHeight()-okraj);
         
         g2d.drawLine(okraj,getHeight()-okraj, getWidth()-okraj , getHeight()-okraj);
        
         final float dash1[] = {25.0f,25.0f};
         final BasicStroke dashed =  new BasicStroke(0.5f,                      // Width
                 BasicStroke.CAP_SQUARE,    // End cap
                 BasicStroke.JOIN_MITER,    // Join style
                 1.5f,                     // Miter limit
                 new float[] {3.0f,3.0f}, // Dash pattern
                 0.0f);
         
         g2d.setStroke(dashed);
         for (int i = 0; i <= getHeight()-80; i+=60*_scaleVykresu) {
        	  g2d.drawLine(okraj,getHeight()-okraj-i, getWidth()-okraj , getHeight()-okraj-i);
		}
         
         for (int i = 0; i <= getWidth()-50; i+=60*_scaleVykresu) {
        	 g2d.drawLine(okraj+i, okraj, okraj+i , getHeight()-okraj);
		}
     }
	
}
