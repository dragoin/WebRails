package Cricket_App;

import java.awt.EventQueue;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Label;
import java.awt.Paint;
import java.awt.Point;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.DefaultCaret;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.xml.soap.Node;

import TCPport.Client;
import TCPport.WriteSerial;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

import Cricket.Cricket;
import Cricket.Data;
import Cricket.Koordinace;

import Cricket.Main;
import Cricket.Packet;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.Canvas;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.RowSpec;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import net.miginfocom.swing.MigLayout;
import java.awt.GridLayout;
import java.awt.Font;

public class AppWindow {

	static public int OFFSET_Height = 100;
	static public int OFFSET_Weight = 20;
	
	private JFrame frame = new JFrame();
	
	private Packet _packet; 
	private DefaultListModel listModel_Data;
	private DefaultListModel listModel_Cricket;
	private VykresCricketu vykresCricketu = new VykresCricketu();;
	
	private DefaultMutableTreeNode rootNode;
	private DefaultTreeModel treeModel;
	private String _serialPort = "COM3";
	
	private double _scaleVykresu = 1; 
	private Kotva kotva = new Kotva(_scaleVykresu);
	private OvalComponent ovalComponent = new OvalComponent();
	private OvalComponent TrilComp = new OvalComponent();
	private  JTextArea dataLog = new JTextArea();
	private JLabel labeldata = new JLabel("NaN");
	
	private String datalog= "=============NEW LOG FILE===============\n";
	
	private List<Point2D> _list = new ArrayList<Point2D>();
	private JTextField serialPortNazev;
	private JTextField textSETX;
	private JTextField textSETY;
	
	private   ImageDraw image;
	private JSlider sliderScale ;
	private JSlider sliderOpacity;
	
	private Point _p_old =new Point(0,0);
	
	private JCheckBox chckbxSettingsPicture;
	private JTextField textFieldUzel1;
	private JTextField textFieldUzel2;
	private JTextField textFieldUzel3;
	private JTextField textFieldUzel4;
	private JTextField textFieldUzel5;
	private JTextField textFieldUzel6;
	private JTextField textFieldUzel7;
	private JTextField textFieldSetScale;
	
	private JSlider sliderSetScale;
	
	private JLabel labelGrid; 
	
	private JLabel labelUzel1;
	private JLabel labelUzel2;
	private JLabel labelUzel3;
	private JLabel labelUzel4;
	private JLabel labelUzel5;
	private JLabel labelUzel6;
	private JLabel labelUzel7;
	private JTextField textFieldSouradniceB1;
	private JTextField textFieldSouradniceB2;
	private JTextField textFieldSouradniceB3;
	private JTextField textFieldSouradniceB4;
	private JTextField textFieldSouradniceB5;
	private JTextField textFieldSouradniceB6;
	private JTextField textFieldSouradniceB7;
	private JLabel lblNewLabel_1;
	private JLabel TrilXY;
	private JLabel lblNewLabel_2;
	private JPanel panel;
	
	
	/**
	 * Launch the application.
	 */
	public void main(String[] args) {
		
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppWindow window = new AppWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
	
	}

	/**
	 * Create the application.
	 */
	public AppWindow() {
		initialize();
		
		
		
		
		
	}
	
	private void setupLabel(String item){
		Cricket cricket = Main.data.get_List_Cricketu_vizName(item);
		switch (item) {
		
		case "BEACON 1":
			textFieldSouradniceB1.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 2":
			textFieldSouradniceB2.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 3":
			textFieldSouradniceB3.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 4":
			textFieldSouradniceB4.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 5":
			textFieldSouradniceB5.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 6":
			textFieldSouradniceB6.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		case "BEACON 7":
			textFieldSouradniceB7.setText("["
					+ cricket.get_XY_pozice_kotvy().get_x()
					+ ";"
					+ cricket.get_XY_pozice_kotvy().get_y()
					+ "]");
			break;
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		 
		
	 
		frame.getContentPane().setBackground(new Color(238, 238, 238));
		frame.getContentPane().setLayout(null);
		
		
		
		vykresCricketu.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		vykresCricketu.setBackground(Color.WHITE);
		vykresCricketu.setBounds(247, 26, 940, 531);
		
		
		vykresCricketu.setLayout(null);
		
		ovalComponent.setBorder(null);
		ovalComponent.setBackground(Color.WHITE);
		//ovalComponent= new OvalComponent(new Koordinace(40, 40));
		ovalComponent.setSize(940, 531);
		ovalComponent.setLocation(0,0);
		
	
		vykresCricketu.add(ovalComponent);
		//
	
	
		TrilComp.setBorder(null);
		TrilComp.setBackground(Color.WHITE);
		//ovalComponent= new OvalComponent(new Koordinace(40, 40));
		TrilComp.setSize(940, 531);
		TrilComp.setLocation(0,0);
		TrilComp.setSouradnice(180, 180, _scaleVykresu);
		TrilComp.setColor(Color.CYAN);
		vykresCricketu.add(TrilComp);

		frame.getContentPane().add(vykresCricketu);
		
		inicializace_Kotev();
	
		JLabel lblLokalizaceBeacnu = new JLabel("Cricket Lokalization");
		lblLokalizaceBeacnu.setFont(new Font("Dialog", Font.BOLD, 20));
		lblLokalizaceBeacnu.setBounds(12, 12, 229, 35);
		frame.getContentPane().add(lblLokalizaceBeacnu);
		
		synchronized (Main.class) {
			
				Main.data.addPropertyChangeListener(new PropertyChangeListener()
				{
					@Override
					public void propertyChange(PropertyChangeEvent event) {
						// TODO Auto-generated method stub
						/*
						 textFieldUzel1.setBackground(Color.white);
						 
						textFieldUzel2.setBackground(Color.white);
						textFieldUzel3.setBackground(Color.white);
						textFieldUzel4.setBackground(Color.white);
						textFieldUzel5.setBackground(Color.white);
						textFieldUzel6.setBackground(Color.white);
	            		textFieldUzel7.setBackground(Color.white);
	            		*/
						 if (event.getPropertyName().equals("name")) {
					           // System.out.println(event.getNewValue().toString());
					         // System.out.println("+++" + Main.data.getCricket().get_name() );  
					            //synchronized (Main.class) {
									
					            	//System.out.println("Data"+" "+Main.data.get_XYsouradnice().get_x()+" " + Main.data.get_XYsouradnice().get_y() ); 
					            	//vykresCricketu.add(new OvalComponent(Main.data.get_XYsouradnice()));
					            	try {
					            		double x =Main.data.get_XYsouradnice().get_x();
					            		double y = Main.data.get_XYsouradnice().get_y();
					            		double xTri =Main.data.get_XYTrilaterace().get_x();
					            		double yTri = Main.data.get_XYTrilaterace().get_y();
					            		Point2D p = new Point2D.Double(x, y);
					            		/*if((x & y) != 0)
					            		{
					            		_list.add(p);
					            		*/
											
					            		if (Main.data.getCricket().getOld())
				            			{
				            				
				            			}
					            		else
					            		{
					            		switch(Main.data.getCricket().get_name())
					            		{
					            		case "BEACON 1":
					            			textFieldUzel1.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel1.setBackground(Color.green);
					            			break;
					            		case "BEACON 2":
					            			textFieldUzel2.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel2.setBackground(Color.green);
					            			break;
					            		case "BEACON 3":
					            			textFieldUzel3.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel3.setBackground(Color.green);
					            			break;
					            		case "BEACON 4":
					            			textFieldUzel4.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel4.setBackground(Color.green);
					            			break;
					            		case "BEACON 5":
					            			textFieldUzel5.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel5.setBackground(Color.green);
					            			break;
					            		case "BEACON 6":
					            			textFieldUzel6.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel6.setBackground(Color.green);
					            			break;
					            			
					            		case "BEACON 7":
					            			
					            			textFieldUzel7.setText(new String(""+Main.data.getCricket().getRSSI()));
					            			textFieldUzel7.setBackground(Color.green);
					            			break;
					            			
					            		}
					            		}
					            		//ZMENA POZICE
					            		ovalComponent.setSouradnice(x,y,_scaleVykresu);
					            		TrilComp.setSouradnice(xTri, yTri, _scaleVykresu);
					            		//System.out.println(xTri +" "+ yTri);
					            		
					            		datalog = dataLog.getText();
					            		
					            		for (Cricket cricket : Main.data.get_listCricketu().values())
					            		{
					            			if (cricket.getOld())
					            			{
					            				switch(cricket.get_name())
							            		{
							            		case "BEACON 1":
							            			textFieldUzel1.setBackground(Color.red);
							            			break;
							            		case "BEACON 2":
							            			textFieldUzel2.setBackground(Color.red);
							            			break;
							            		case "BEACON 3":
							            			textFieldUzel3.setBackground(Color.red);
							            			break;
							            		case "BEACON 4":
							            			textFieldUzel4.setBackground(Color.red);
							            			break;
							            		case "BEACON 5":
							            			textFieldUzel5.setBackground(Color.red);
							            			break;
							            		case "BEACON 6":
							            			textFieldUzel6.setBackground(Color.red);
							            			break;
							            			
							            		case "BEACON 7":
							            			textFieldUzel7.setBackground(Color.red);
							            			break;
							            			
							            		}
					            			}else
					            			{
					            				//if(cricket.getRSSI()!=0)
							            		//{
					            				
							            			datalog +=(cricket.get_name()+"/ P[ /"+ cricket.get_XY_pozice_kotvy().get_x()+"/ ; /"+cricket.get_XY_pozice_kotvy().get_y()+ "/ ] DISTANCE [ /" +cricket.getRSSI() +"/ ;] \n");
							            		//}
					            			
					            			}
					            		}
					            		 
					            		datalog +=("Lokalizace WCL[X , Y] = [ /" + x + "/ ; /"+ y +"/ ]\n");
					            		datalog +=("Lokalizace Trilaterace[X , Y] = [ /" + xTri + "/ ; /"+ yTri +"/ ]\n");
					            		dataLog.setText(datalog);
					            		labeldata.setText("["+(int)x+" "+(int)y +"]");
					            		
					            		TrilXY.setText("["+(int)xTri+" "+(int)yTri +"]");
					            		            		
					            		vykresCricketu.repaint();
					            		frame.repaint();
					            		
					            		
									} catch (Exception e) {
										// TODO: handle exception
										System.out.println(e);
										dataLog.setText("error location");
									}
					            
					            	//System.out.println((int)Main.data.get_XYsouradnice().get_x() + " "+(int)Main.data.get_XYsouradnice().get_y());
								//}
					        }
						
					}
					
				}
						);
				
			}
		  
		  TableData model = new TableData();
		 // model.addTableModelListener(new ListenerData());
		  
		  model.setData();
		  
		  
		  rootNode = new DefaultMutableTreeNode("Root Node");
		  
		  createNodes(rootNode);
		  
		  
		  treeModel = new DefaultTreeModel(rootNode);
		  treeModel.addTreeModelListener(new MyTreeModelListener());
		  
		  JLabel lblGrid = new JLabel("Grid : ");
		  lblGrid.setBounds(247, 10, 40, 14);
		  frame.getContentPane().add(lblGrid);
		  
		  labelGrid = new JLabel("[ 60 ; 60 ] cm");
		  labelGrid.setBounds(295, 10, 107, 14);
		  frame.getContentPane().add(labelGrid);
		  
		  JButton tlSave = new JButton("Save Log");
		  tlSave.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  	
		  		JFileChooser saveFile = new JFileChooser();
		  		saveFile.setDialogTitle("Specify a file to save"); 
               
                if ( saveFile.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
                File fileToSave = saveFile.getSelectedFile();
                
                IO_file IO = new IO_file();
                IO.save(fileToSave, datalog);
                
                }
		  		
		  	}
		  	
		  });
		  tlSave.setBounds(799, 669, 102, 35);
		  frame.getContentPane().add(tlSave);
		  
		  JScrollPane Scrollauto = new JScrollPane();
		  Scrollauto.setBounds(919, 572, 268, 136);
		  frame.getContentPane().add(Scrollauto);
		  //Automaticke scrolovani
		  Scrollauto.setViewportView(dataLog);
		  
		  JButton btnConnect = new JButton("Start");
		 //PRIPOJENI // VYTVORENI VLAKNA
		  btnConnect.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  	
		  		_serialPort=serialPortNazev.getText();
		  		
		  		dataLog.setText("Pripojeni " + _serialPort);
		  		
		  	
		  	final Thread client = new Client("VlaknoClient",_serialPort);
			client.start();
		
			
			Thread Test = new Thread(){
				public void run() {
				
					
					while(client.isAlive())
					{
					serialPortNazev.setBackground(Color.GREEN);
				
					try {
						sleep(5000);
						serialPortNazev.setBackground(Color.white);
						sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					}
					
					serialPortNazev.setBackground(Color.red);
					
					
				}
			};
			
			Test.start();
			
			
		  	}
		  });
		  
		  
		  btnConnect.setBounds(257, 642, 117, 25);
		  frame.getContentPane().add(btnConnect);
		  //NASTAVENI SERIOVEHO PORTU
		  
		  serialPortNazev = new JTextField();
		  serialPortNazev.setText(_serialPort);
		  serialPortNazev.setBounds(257, 602, 117, 28);
		  frame.getContentPane().add(serialPortNazev);
		  serialPortNazev.setColumns(10);
		  
		  JLabel lblSeriovyPort = new JLabel("Serial Port");
		  lblSeriovyPort.setBounds(257, 569, 127, 15);
		  frame.getContentPane().add(lblSeriovyPort);
		  
		  
		  final JComboBox comboCricket = new JComboBox();
		  comboCricket.addItemListener(new ItemListener() {
		  	public void itemStateChanged(ItemEvent arg0) {
		  	  synchronized (Main.class) {
		  		String item = comboCricket.getSelectedItem().toString();
		  		textSETX.setText(String.valueOf(Main.data.get_List_Cricketu_vizName(item).get_XY_pozice_kotvy().get_x()));
		  		textSETY.setText(String.valueOf(Main.data.get_List_Cricketu_vizName(item).get_XY_pozice_kotvy().get_y()));
			}
		  		
		  	}
		  });
		  comboCricket.setBackground(Color.WHITE);
		  comboCricket.setBounds(12, 456, 155, 25);
		  frame.getContentPane().add(comboCricket);
		  
		  
		  JLabel lblSettingsCricket = new JLabel("Settings Crickets");
		  lblSettingsCricket.setBounds(12, 422, 135, 25);
		  frame.getContentPane().add(lblSettingsCricket);
		  
		  textSETX = new JTextField();
		  textSETX.setToolTipText("Setup X");
		  textSETX.setBounds(36, 504, 76, 25);
		  frame.getContentPane().add(textSETX);
		  textSETX.setColumns(10);
		  
		  textSETY = new JTextField();
		  textSETY.setBounds(36, 531, 76, 25);
		  frame.getContentPane().add(textSETY);
		  textSETY.setColumns(10);
		  
		  JLabel lblX = new JLabel("X");
		  lblX.setBounds(12, 506, 24, 20);
		  frame.getContentPane().add(lblX);
		  
		  JLabel lblY = new JLabel("Y");
		  lblY.setBounds(12, 536, 24, 15);
		  frame.getContentPane().add(lblY);
		
		  synchronized (Main.class) {
			 
			  for (Cricket cricket : Main.data.get_listCricketu().values()){
			  comboCricket.addItem(cricket.get_name());
			  }
		  
		  }
		  ///SET hodnoty
		  JButton btnNewButton_1 = new JButton("Set");
		  btnNewButton_1.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent e) {
		  	try {
				
		  	String item = comboCricket.getSelectedItem().toString();
		  		
		  	
		  	
		  	if((textSETX.getText()=="")|(textSETY.getText()==""))
		  	{
		  	throw new Exception();	
		  	}
		  	else
		  	{
		  		Double x = Double.valueOf(textSETX.getText());
		  		Double y = Double.valueOf(textSETY.getText());
		  		
		  		 synchronized (Main.class) {
		  			
		  			 Main.data.get_List_Cricketu_vizName(item).get_XY_pozice_kotvy().set_x(x);
		  			 Main.data.get_List_Cricketu_vizName(item).get_XY_pozice_kotvy().set_y(y);
		  			inicializace_Kotev();
		  			
		  			setupLabel(item);
		  			/*for (TreeNode node :rootNode.children()){
		  				System.out.println(node.toString());
		  			}*/
		  		 }
		  	}
		  	}
			catch (NumberFormatException e2) {
				// TODO: handle exception
		  		JOptionPane.showMessageDialog(new JFrame("Error"),
					    "Zadej cisla");
			}
			 catch (Exception e2) {
				// TODO: handle exception
				JOptionPane.showMessageDialog(new JFrame("Error"),
					    "Zadej hodnoty ");
			}
		  
		  		
		  	}
		  });
		  
		  
		  btnNewButton_1.setBounds(124, 532, 57, 25);
		  frame.getContentPane().add(btnNewButton_1);
		  
		  JButton tlObrazek = new JButton("Load Picture");
		  tlObrazek.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {

				JFileChooser saveFile = new JFileChooser();
				saveFile.setDialogTitle("Specify a file to save");

				if (saveFile.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					
					File fileToOpen = saveFile.getSelectedFile();
					BufferedImage img = null;
					try {
					    img = ImageIO.read(fileToOpen);
					    image = new ImageDraw(img);
					    image.setBounds(0, 0, 2000, 2000);
					    
					    vykresCricketu.add(image);
					    image.setScale(100);
					    
					} catch (IOException e) {
					}
			
				}
			}
		});
		
		  tlObrazek.setBounds(497, 568, 129, 25);
		  frame.getContentPane().add(tlObrazek);
		  
		  final JPanel panelSettings = new JPanel();
		  panelSettings.setBounds(497, 602, 240, 105);
		  panelSettings.setVisible(false);
		  frame.getContentPane().add(panelSettings);
		  panelSettings.setLayout(null);
		  
		  chckbxSettingsPicture = new JCheckBox("Settings Image");
		  chckbxSettingsPicture.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				
				if (chckbxSettingsPicture.isSelected()) {
					if (image == null) {
						JOptionPane.showMessageDialog(null, "Load Image");
					} else {
						panelSettings.setVisible(chckbxSettingsPicture
								.isSelected());
					}
				}
				else
				{
					panelSettings.setVisible(chckbxSettingsPicture
							.isSelected());
				}
			}
		  });
		  chckbxSettingsPicture.setBounds(642, 574, 114, 23);
		  frame.getContentPane().add(chckbxSettingsPicture);
		  
		
		  
		  JLabel lblScale = new JLabel("Scale");
		  lblScale.setBounds(12, 58, 87, 16);
		  lblScale.setHorizontalAlignment(SwingConstants.LEFT);
		  panelSettings.add(lblScale);
		  
		  sliderScale = new JSlider();
		  sliderScale.setBounds(95, 58, 133, 16);
		  panelSettings.add(sliderScale);
		  
		    sliderScale.addChangeListener(new ChangeListener() {
		    	public void stateChanged(ChangeEvent arg0) {
		    		
		    		image.setScale(sliderScale.getValue());
		    		
		    	}
		    });
		  
		  JLabel lblOpacity = new JLabel("Opacity");
		  lblOpacity.setBounds(12, 86, 87, 16);
		  lblOpacity.setHorizontalAlignment(SwingConstants.LEFT);
		  panelSettings.add(lblOpacity);
		  
		  sliderOpacity = new JSlider();
		  sliderOpacity.addChangeListener(new ChangeListener() {
		  	public void stateChanged(ChangeEvent arg0) {
		  		
		  		image.setOpacity(sliderOpacity.getValue());
		  	}
		  });
		  sliderOpacity.setBounds(95, 86, 133, 16);
		  panelSettings.add(sliderOpacity);
		  
		  JLabel lblRotat = new JLabel("Rotate");
		  lblRotat.setHorizontalAlignment(SwingConstants.LEFT);
		  lblRotat.setBounds(12, 12, 70, 15);
		  panelSettings.add(lblRotat);
		  
		  final JSlider slider = new JSlider();
		  slider.setPaintTicks(true);
		  slider.setMajorTickSpacing(45);
		  slider.setSnapToTicks(true);
		  slider.setMaximum(360);
		  slider.addChangeListener(new ChangeListener() {
		  	public void stateChanged(ChangeEvent e) {
		  		image.setRotate(slider.getValue());
		  	}
		  });
		  slider.setBounds(95, 12, 133, 34);
		  panelSettings.add(slider);
		  
		  labelUzel1 = new JLabel("Beacon 1");
		  labelUzel1.setBounds(22, 239, 70, 14);
		  frame.getContentPane().add(labelUzel1);
		  
		  labelUzel2 = new JLabel("Beacon 2");
		  labelUzel2.setBounds(22, 264, 70, 14);
		  frame.getContentPane().add(labelUzel2);
		  
		  textFieldUzel1 = new JTextField();
		  textFieldUzel1.setBackground(Color.WHITE);
		  textFieldUzel1.setEditable(false);
		  textFieldUzel1.setBounds(97, 239, 46, 20);
		  frame.getContentPane().add(textFieldUzel1);
		  textFieldUzel1.setColumns(10);
		  
		  textFieldUzel2 = new JTextField();
		  textFieldUzel2.setBackground(Color.WHITE);
		  textFieldUzel2.setEditable(false);
		  textFieldUzel2.setBounds(97, 264, 46, 20);
		  frame.getContentPane().add(textFieldUzel2);
		  textFieldUzel2.setColumns(10);
		  
		  textFieldUzel3 = new JTextField();
		  textFieldUzel3.setBackground(Color.WHITE);
		  textFieldUzel3.setEditable(false);
		  textFieldUzel3.setBounds(97, 289, 46, 20);
		  frame.getContentPane().add(textFieldUzel3);
		  textFieldUzel3.setColumns(10);
		  
		  labelUzel3 = new JLabel("Beacon 3");
		  labelUzel3.setBounds(22, 289, 70, 14);
		  frame.getContentPane().add(labelUzel3);
		  
		  labelUzel4 = new JLabel("Beacon 4");
		  labelUzel4.setBounds(22, 314, 70, 14);
		  frame.getContentPane().add(labelUzel4);
		  
		  textFieldUzel4 = new JTextField();
		  textFieldUzel4.setBackground(Color.WHITE);
		  textFieldUzel4.setEditable(false);
		  textFieldUzel4.setBounds(97, 314, 46, 20);
		  frame.getContentPane().add(textFieldUzel4);
		  textFieldUzel4.setColumns(10);
		  
		  labelUzel5 = new JLabel("Beacon 5");
		  labelUzel5.setBounds(22, 340, 70, 14);
		  frame.getContentPane().add(labelUzel5);
		  
		  textFieldUzel5 = new JTextField();
		  textFieldUzel5.setBackground(Color.WHITE);
		  textFieldUzel5.setEditable(false);
		  textFieldUzel5.setBounds(97, 340, 46, 20);
		  frame.getContentPane().add(textFieldUzel5);
		  textFieldUzel5.setColumns(10);
		  
		  textFieldUzel6 = new JTextField();
		  textFieldUzel6.setBackground(Color.WHITE);
		  textFieldUzel6.setEditable(false);
		  textFieldUzel6.setBounds(97, 365, 46, 20);
		  frame.getContentPane().add(textFieldUzel6);
		  textFieldUzel6.setColumns(10);
		  
		  textFieldUzel7 = new JTextField();
		  textFieldUzel7.setBackground(Color.WHITE);
		  textFieldUzel7.setEditable(false);
		  textFieldUzel7.setBounds(97, 390, 46, 20);
		  frame.getContentPane().add(textFieldUzel7);
		  textFieldUzel7.setColumns(10);
		  
		  labelUzel6 = new JLabel("Beacon 6");
		  labelUzel6.setBounds(22, 365, 70, 14);
		  frame.getContentPane().add(labelUzel6);
		  
		  labelUzel7 = new JLabel("Beacon 7");
		  labelUzel7.setBounds(22, 390, 70, 14);
		  frame.getContentPane().add(labelUzel7);
		  
		  
		  
		  JLabel lblSetScale = new JLabel("Set Scale ");
		  lblSetScale.setBounds(762, 578, 76, 14);
		  frame.getContentPane().add(lblSetScale);
		  
		  textFieldSetScale = new JTextField();
		  textFieldSetScale.setBounds(762, 638, 46, 20);
		  frame.getContentPane().add(textFieldSetScale);
		  textFieldSetScale.setColumns(10);
		  textFieldSetScale.setText("1");
		  DefaultCaret caret = (DefaultCaret) dataLog.getCaret();
		  caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		  
		  
		  sliderSetScale = new JSlider();
		  sliderSetScale.setMinimum(10);
		  sliderSetScale.setMinorTickSpacing(25);
		  sliderSetScale.setMajorTickSpacing(50);
		  sliderSetScale.setPaintTicks(true);
		  sliderSetScale.setValue(100);
		  sliderSetScale.setMaximum(200);
		  
		  sliderSetScale.addChangeListener(new ChangeListener() {
		  	public void stateChanged(ChangeEvent arg0) {
		  		_scaleVykresu=(double)sliderSetScale.getValue()/100;
		  		textFieldSetScale.setText(String.valueOf(_scaleVykresu));
		  		
		  		
		  	}
		  });
		  sliderSetScale.setBounds(762, 595, 139, 35);
		  frame.getContentPane().add(sliderSetScale);
		  
		  JButton tl_repaint = new JButton("Repaint");
		  tl_repaint.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		
		  		kotva.setSouradnice(_scaleVykresu);
		  		vykresCricketu.prekresli(_scaleVykresu);
		  		
		  		
		  	}
		  });
		  tl_repaint.setBounds(813, 635, 88, 23);
		  frame.getContentPane().add(tl_repaint);
		  
		  JLabel lblCoordination = new JLabel("Coordinates");
		  lblCoordination.setBounds(149, 213, 82, 14);
		  frame.getContentPane().add(lblCoordination);
		  
		  textFieldSouradniceB1 = new JTextField();
		  textFieldSouradniceB1.setBackground(Color.WHITE);
		  textFieldSouradniceB1.setEditable(false);
		  textFieldSouradniceB1.setBounds(149, 239, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB1);
		  textFieldSouradniceB1.setColumns(10);
		  
		  textFieldSouradniceB2 = new JTextField();
		  textFieldSouradniceB2.setBackground(Color.WHITE);
		  textFieldSouradniceB2.setEditable(false);
		  textFieldSouradniceB2.setBounds(149, 264, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB2);
		  textFieldSouradniceB2.setColumns(10);
		  
		  textFieldSouradniceB3 = new JTextField();
		  textFieldSouradniceB3.setBackground(Color.WHITE);
		  textFieldSouradniceB3.setEditable(false);
		  textFieldSouradniceB3.setBounds(149, 289, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB3);
		  textFieldSouradniceB3.setColumns(10);
		  
		  textFieldSouradniceB4 = new JTextField();
		  textFieldSouradniceB4.setBackground(Color.WHITE);
		  textFieldSouradniceB4.setEditable(false);
		  textFieldSouradniceB4.setBounds(149, 314, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB4);
		  textFieldSouradniceB4.setColumns(10);
		  
		  textFieldSouradniceB5 = new JTextField();
		  textFieldSouradniceB5.setBackground(Color.WHITE);
		  textFieldSouradniceB5.setEditable(false);
		  textFieldSouradniceB5.setBounds(149, 340, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB5);
		  textFieldSouradniceB5.setColumns(10);
		  
		  textFieldSouradniceB6 = new JTextField();
		  textFieldSouradniceB6.setBackground(Color.WHITE);
		  textFieldSouradniceB6.setEditable(false);
		  textFieldSouradniceB6.setBounds(149, 365, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB6);
		  textFieldSouradniceB6.setColumns(10);
		  
		  textFieldSouradniceB7 = new JTextField();
		  textFieldSouradniceB7.setBackground(Color.WHITE);
		  textFieldSouradniceB7.setEditable(false);
		  textFieldSouradniceB7.setBounds(149, 390, 86, 20);
		  frame.getContentPane().add(textFieldSouradniceB7);
		  textFieldSouradniceB7.setColumns(10);
		  
		  JButton btnNewButton = new JButton("Clear");
		  btnNewButton.addActionListener(new ActionListener() {
		  	public void actionPerformed(ActionEvent arg0) {
		  		datalog = "";
		  		dataLog.setText(datalog);
		  		
		  	  synchronized (Main.class) {
				  Main.data.Clear();  
				  }
		  		
		  	}
		  });
		  btnNewButton.setBounds(831, 568, 70, 29);
		  frame.getContentPane().add(btnNewButton);
		  
		  lblNewLabel_2 = new JLabel("Distance");
		  lblNewLabel_2.setBounds(79, 212, 70, 15);
		  frame.getContentPane().add(lblNewLabel_2);
		  
		  panel = new JPanel();
		  panel.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		  panel.setBackground(Color.WHITE);
		  panel.setBounds(12, 77, 229, 124);
		  frame.getContentPane().add(panel);
		  panel.setLayout(null);
		  
		  lblNewLabel_1 = new JLabel("Trilateration");
		  lblNewLabel_1.setBounds(12, 62, 107, 25);
		  panel.add(lblNewLabel_1);
		  
		  TrilXY = new JLabel("NaN");
		  TrilXY.setFont(new Font("Dialog", Font.PLAIN, 20));
		  TrilXY.setBounds(117, 74, 112, 25);
		  panel.add(TrilXY);
		  labeldata.setBounds(117, 27, 135, 35);
		  panel.add(labeldata);
		  labeldata.setBackground(Color.YELLOW);
		  labeldata.setFont(new Font("Dialog", Font.PLAIN, 20));
		  
		  JLabel lblXY = new JLabel(" [  X  ,   Y  ] (cm)");
		  lblXY.setBounds(117, 7, 112, 24);
		  panel.add(lblXY);
		  
		  JLabel lblNewLabel = new JLabel("WCL");
		  lblNewLabel.setBackground(Color.ORANGE);
		  lblNewLabel.setBounds(12, 27, 70, 15);
		  panel.add(lblNewLabel);
		  
		  synchronized (Main.class) {
			  for (Cricket cricket : Main.data.get_listCricketu().values()){
				setupLabel(cricket.get_name());
				//Label text = new Label("["+x+";"+y+"]");
				//vykresCricketu.add(text);
				  
			  }
		}
		frame.setBounds(100, 100, 1201, 753);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
			
	}
	
		 
	private void createNodes(DefaultMutableTreeNode top) {
	    DefaultMutableTreeNode category = null;
	    DefaultMutableTreeNode book = null;

		  synchronized (Main.class) {
			 /*
			  for (String ID  : Main.data.get_listCricketu().keySet())
			  {
			   */
			  
			  
			  

		    	for (Cricket cricket : Main.data.get_listCricketu().values()){
		    		
		    		
		    		
		    		
			    	category = new DefaultMutableTreeNode(cricket.get_name());
			    	top.add(category);
			    	  
			    	
			    	
			    	
					book = new DefaultMutableTreeNode(" "+cricket.get_ID());
					category.add(book);
			    	
					book = new DefaultMutableTreeNode("x: "+cricket.get_XY_pozice_kotvy().get_x());
					category.add(book); 
					book = new DefaultMutableTreeNode("y: "+cricket.get_XY_pozice_kotvy().get_y());
					category.add(book);
					
					  book = new DefaultMutableTreeNode("Vahovy koeficient "+cricket.get_wij());
					category.add(book);
					  
			  }
			
			 
			    
		  }
		  
		
	    	
	 
	}
	
	public void inicializace_Kotev() {
		kotva.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				if(chckbxSettingsPicture.isSelected()){
				Point position = new Point(_p_old.x-e.getX(),_p_old.y-e.getPoint().y);
				Point rohOkna = image.getLocation();
				image.setLocation(rohOkna.x-position.x,rohOkna.y-position.y);
				_p_old = e.getPoint();
				}
			}
			@Override
			public void mouseMoved(MouseEvent e) {
				_p_old=e.getPoint();
			}
		});
		
		
	
		
		kotva.setBounds(10, 11, 940, 531);
		vykresCricketu.add(kotva);
		kotva.setBorder(null);
		kotva.setBackground(Color.WHITE);
		
		JLabel label = new JLabel("[0 ; 0]");
		label.setBounds(12, 498, 70, 21);
		vykresCricketu.add(label);
		
			 
		 int x =10;
		 int y =10;
		 
			  kotva.setSouradnice(_scaleVykresu);  
			 
			
		  
	}
	
	public void zmenenaCricket(Double d) {
		
		System.out.println("Listener " + d);
	}
}
