package Cricket_App;

import java.util.List;
import java.util.Map;

import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import Cricket.Cricket;
import Cricket.Main;

public class TreeData implements TreeModel {
	
	
	private String root = "Seznam Cricketu";
	private Map<String,Cricket> neaktualniData;
	private String[] child = {"mapa","Pepa","Karel"};
			
	public TreeData() {
		// TODO Auto-generated constructor stub
	synchronized (Main.class) {
		neaktualniData = Main.data.get_listCricketu();
	}
	
	
	
	}
	@Override
	public void addTreeModelListener(TreeModelListener arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object getChild(Object arg0, int arg1) {
		// TODO Auto-generated method stub
		return child.toString();
	}

	@Override
	public int getChildCount(Object arg0) {
		// TODO Auto-generated method stub
		return child.length;
	}

	@Override
	public int getIndexOfChild(Object arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	    if (child == null) return -1;
	  
	    String childname = child[0];
	    for(int i = 0; i < child.length; i++) {
	      if (childname.equals(child[i])) return i;
	    }
	    return -1;
	  }
	


	@Override
	public Object getRoot() {
		// TODO Auto-generated method stub
		return root;
	}

	@Override
	public boolean isLeaf(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeTreeModelListener(TreeModelListener arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void valueForPathChanged(TreePath arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}

}
