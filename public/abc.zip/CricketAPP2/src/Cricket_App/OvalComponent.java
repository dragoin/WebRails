package Cricket_App;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;

import javax.swing.JComponent;

import Cricket.Koordinace;

public class OvalComponent extends JComponent {
	 
	
	private Koordinace _souradnice = new Koordinace(10, 10);
	private Color _color = Color.red;
	private double _scaleVykres =1;
	
		public OvalComponent() {
			// TODO Auto-generated constructor stub
		}
		public OvalComponent(Koordinace souradnice) {
			// TODO Auto-generated constructor stub
			_souradnice = souradnice;
			
		}
		public void setColor (Color color){
			_color = color;
			repaint();
		}
		public void setSouradnice(double x,double y,double Scale)
		{
			_scaleVykres = Scale;
			_souradnice.set_x(x);
			_souradnice.set_y(y);
			repaint();
		}
	@Override
	    public void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        Graphics2D g2 = (Graphics2D) g;
	        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, // Anti-alias!
	                RenderingHints.VALUE_ANTIALIAS_ON);
	        //g.fillOval((int)_souradnice.get_x(),(int) _souradnice.get_y(), 20, 20);
	        
	        double x = (_souradnice.get_x()*_scaleVykres)+25;
	        double y = 497-(_souradnice.get_y()*_scaleVykres);
	        
	        
	      
	        g2.setColor(Color.black);
	        
	        Ellipse2D e = new Ellipse2D.Double(x-2.5, y-2.5, 15, 15);
	        g2.fill(e);
	       
	        g2.fillRect((int)x+5,(int)y+7,65,17);
	       
	        
	        g2.setColor(_color);
	        g2.fillOval((int)x,(int)y,10,10);
	       
	        g2.drawString(new String((int)_souradnice.get_x() +"; "+(int)_souradnice.get_y()), (int)x+10, (int)y+20);
	        
	       
	        
	    }

}
