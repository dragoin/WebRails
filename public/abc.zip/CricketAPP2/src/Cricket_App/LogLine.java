package Cricket_App;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.geom.GeneralPath;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;

public class LogLine  extends JComponent{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Point2D> _list = new ArrayList<Point2D>();
	
 
	
	public LogLine() {
		// TODO Auto-generated constructor stub
		
	}
	
	public void setLine(List<Point2D> p) {
		// TODO Auto-generated constructor stub
		 
		_list.addAll(p);
		repaint();
	}
	public void setLine(Point2D p) {
		// TODO Auto-generated constructor stub
		 
		_list.add(p);
		repaint();
	}
	
	@Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        
        g2.setColor(Color.RED);
        g2.setStroke(new BasicStroke(2F));
        Path2D polyline = new Path2D.Double();
       

        	polyline.moveTo(100, 100);
        for (Point2D a : _list)
        {
        	
        	polyline.lineTo((a.getX()*2+AppWindow.OFFSET_Weight),(a.getY()*2+AppWindow.OFFSET_Height));
        }
        	g2.draw(polyline);
     
	}
        
        


}
