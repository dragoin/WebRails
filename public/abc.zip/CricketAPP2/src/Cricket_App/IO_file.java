package Cricket_App;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class IO_file {

	public void save (File file,String text){
	
		try {
			// Create file
			FileWriter fstream = new FileWriter(file);
			BufferedWriter out = new BufferedWriter(fstream);
			
			System.out.println(text);
			
			out.write(text + "\n");
			// Close the output stream
			out.close();
			JOptionPane.showMessageDialog(null, "File saved");
		 
		} catch (Exception e) {// Catch exception if any
			
			JOptionPane.showMessageDialog(new JFrame("Error"),
					e.getMessage());
		}
	}
}
