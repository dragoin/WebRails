package Cricket_App;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Label;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;

import org.omg.PortableServer._ServantActivatorStub;

import Cricket.Cricket;
import Cricket.Koordinace;
import Cricket.Main;

public class Kotva extends JComponent {

	/**
	 * 
	 */
	private Koordinace _souradnice = new Koordinace(10, 10);
	private static final long serialVersionUID = 1L;
	private List<Point2D> _list = new ArrayList<Point2D>();
	private double _scaleVykresu = 1;
	
	public Kotva(double Scale) {
		// TODO Auto-generated constructor stub
		_scaleVykresu = Scale;
	}

	public void setSouradnice(double Scale) {
		_scaleVykresu = Scale;
		repaint();
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D)g;
        
		
		
		//synchronized (Main.class) {
			  for (Cricket cricket : Main.data.get_listCricketu().values()){
				
				//  _list.add(new Point2D.Double(, ));
				 double x = cricket.get_XY_pozice_kotvy().get_x() * _scaleVykresu;
				 double y = cricket.get_XY_pozice_kotvy().get_y()  * _scaleVykresu;
				 x = (x + 20-5) ;
				 y = (482 - y+2.5);
				 
				  g2.setColor(Color.black);
				  g2.fillRect(
							(int) (x-2), 
							(int) (y-2),
							(int) 15, 
							(int) 15);
				  g2.setColor(Color.white);
				  g2.fillRect((int)x+10, (int)y+10, 60, 30);
				  g2.setColor(Color.BLUE);
				  g2.drawString(new String(cricket.get_name()), (int)x+10, (int)y+20);//
				  g2.drawString(new String("["+(int)cricket.get_XY_pozice_kotvy().get_x() +";"+(int)cricket.get_XY_pozice_kotvy().get_y()+"]"),
						  		(int)x+10, 
						  		(int)y+30);
				  
				  g2.fillRect(
							(int) x, 
							(int) y,
							(int) _souradnice.get_x(), 
							(int) _souradnice.get_y());
				
				  
			  }
		
	}

}
