package Cricket;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;


public class Cricket implements ListDataListener {

	private String _ID;
	private String _name;
	private double _uhel=1;
	private double aktualRSSI;
	private Packet _packet;
	private Koordinace _souradnice;
	private List<Packet> _seznamDat = new ArrayList<Packet>();
	
	private Timer cas_paketu = new Timer("Cas Paketu");
	private boolean jestaryPacket = true;
	
	private Koordinace _XYsouradnic;
	private double _wij = 0;
	
	class Casvyprsel extends TimerTask {

        @Override
        public void run() {
            System.out.println(_name + ": Paket je stary");
            jestaryPacket = true;
           cas_paketu.cancel(); //Not necessary because we call System.exit
            //System.exit(0); //Stops the AWT thread (and everything else)
        }
    }


	public Cricket(String ID,String name, double x,double y) {
		// TODO Auto-generated constructor stub
		_name = name;
		_ID = ID;
		jestaryPacket = true;
		_souradnice = new Koordinace(x, y);
	}
	public void addPacket(double Rssi) {
		if(Rssi!=0){
		
			_packet = new Packet(Rssi, _uhel);
			aktualRSSI = Rssi;
			_seznamDat.add(_packet);
			jestaryPacket = false;
			cas_paketu.cancel();
			cas_paketu = new Timer("Cas Paketu");
			cas_paketu.schedule(new Casvyprsel() , 3000);
			VypocetWCL();
		}
		else
		{
			System.out.println(_name+": Packet je nulovy");
		}
	}
	public double getRSSI(){
	return aktualRSSI;
	}
	public boolean getOld(){
		return jestaryPacket;
	}
	
	public void setAngle(double angle){
		_uhel = angle; 
	}
	
	public String get_ID() {
		return _ID;
	}
	public String get_name() {

		return _name;
	}

	public List<Packet> get_seznamDat() {
		return _seznamDat;
	}
	
	public void clear(){
		_seznamDat.clear();
	}
	
	public void VypocetWCL() {
		
		try {
			
			
		//_packet = _seznamDat.get(_seznamDat.);
			if (_packet != null)
			{
		_wij = _packet.get_wij();
		_XYsouradnic = new Koordinace(_wij*_souradnice.get_x(),_wij* _souradnice.get_y());
		
		
		
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Chyba cricket vypocet");
		}
		
		
	}
	public Koordinace get_XY_pozice_kotvy(){
		return _souradnice;
	}
	public Koordinace get_XYsouradnic() {
		return _XYsouradnic;
	}
	public double get_wij() {
		return _wij;
	}
	@Override
	public void contentsChanged(ListDataEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void intervalAdded(ListDataEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void intervalRemoved(ListDataEvent e) {
		// TODO Auto-generated method stub
		
	}
}
