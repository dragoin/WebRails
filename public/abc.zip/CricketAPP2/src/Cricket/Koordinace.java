package Cricket;

public class Koordinace {

	
	
	private double _x = 0;
	private double _y = 0;
	private double _z = 0;
	
	public Koordinace(double x, double y) {
		// TODO Auto-generated constructor stub
		
		_x = x;
		_y = y;
		
				
				
	}
	public double get_x() {
		return _x;
	}
	public double get_y() {
		return _y;
	}
	public void set_x(double x) {
		_x = x;
	}
	public void set_y(double y) {
		_y = y;
	}
	
	
}
