package Cricket;

public class WCL{
	
	
	
	
	public WCL() {
		// TODO Auto-generated constructor stub
		
		vypocet();
	}
	public void vypocet() {
		try {
				
		
		System.out.println("+++++++++++++++++++++++++++++++++++");
		synchronized (Main.class) {
			Main.data.vypocetWCL();	
		}
		
		
		System.out.println("WCL POZICE >> " + String.valueOf(Main.data.get_XYsouradnice().get_x()) +"  "+ String.valueOf(Main.data.get_XYsouradnice().get_y()));
		
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Nenalezl vypoctenou lokaci");
		
	
		
	}
	
}
}