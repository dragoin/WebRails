package Cricket;

import java.util.ArrayList;
import java.util.List;

import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

import Cricket_App.AppWindow;


public class Packet {

	private int name;
	private double _Rssi = 0;
	private double _uhel = 1;
	 
	private double _wij = 1;
	
	
	public Packet(double Rssi, double uhel) {
		// TODO Auto-generated constructor stub
		_Rssi = Rssi;
		_uhel = uhel;
		
		 vypocetWIJ();
	}
	public double get_Rssi() {
		return _Rssi;
	}
	public double get_uhel() {
		return _uhel;
	}
	
	public double get_wij() {
		return _wij;
	}
	
	private void vypocetWIJ() {
		
		_wij = 1/ (Math.pow(_Rssi, _uhel));

	}
	
	
}
