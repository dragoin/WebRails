package Cricket;

import Cricket_App.AppWindow;
import TCPport.*;

public class Main {

	
		public volatile static Data data = new Data();
		//public volatile static Thread client;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 String _retezec = "null";
		 String _ID;
		 Cricket _cricket;
		 Separace _separ= new Separace();
		
		_retezec="ID=01:51:18:18:14:00:00:db";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 1", 660, 60);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}

		_retezec="ID=01:ab:18:18:14:00:00:8d";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 2", 660, 240);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		
		
		_retezec="ID=01:b3:18:18:14:00:00:9c";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 3", 570,420);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		_retezec="ID=01:cf:18:18:14:00:00:79";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 4", 300, 60);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		_retezec="ID=01:71:19:19:14:00:00:1e";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 5", 300,240 );
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		

		_retezec="ID=01:5a:18:18:14:00:00:23";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 6", 480, 60);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		_retezec="ID=01:4c:18:18:14:00:00:ca";
		_ID = _separ.get_ID(_retezec);
		_cricket = new Cricket(_ID,"BEACON 7", 480, 240);
		synchronized (Main.class) {
			Main.data.set_List_Cricketu(_cricket);	
		}
		
		
		
		//client = new Client("VlaknoClient","/dev/ttyUSB0");
		//client.start();
		
		AppWindow window = new AppWindow();
		window.main(args);
		
				
	}

	public void Proved() {
		
		
	}
}
