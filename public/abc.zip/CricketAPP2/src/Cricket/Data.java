package Cricket;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Console;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.EventListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.lang.model.util.SimpleAnnotationValueVisitor6;
import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

import org.ejml.simple.SimpleMatrix;
import org.omg.CORBA._PolicyStub;

import Cricket_App.AppWindow;

public class Data{

	protected PropertyChangeSupport changeSupport;
	private Map<String, Cricket> _listCricketu = new HashMap<String, Cricket>();
	private Cricket _cricket;
	private Koordinace _XYsouradnice = new Koordinace(0, 0);
	private Koordinace _XYTrilaterace = new Koordinace(0,0);
	
	
	public Data() {
		// TODO Auto-generated constructor stub
		changeSupport = new PropertyChangeSupport(this);
		
	}

	public void zmeneno(){
		changeSupport.firePropertyChange("name", _XYsouradnice, "new");//_XYsouradnice
	}
	
	public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
       
    }
	
	public Cricket get_List_Cricketu(String ID) {
		_cricket =_listCricketu.get(ID); 
		return _listCricketu.get(ID);
	}
	private String getID(String Name)
	{
		String ID = null ;
		for(Cricket cricket : _listCricketu.values()){
			if(cricket.get_name() == Name){
				ID = cricket.get_ID();
			}
				
		}
		
		return ID;
	}
	public Cricket get_List_Cricketu_vizName(String Name) {
		String ID = getID(Name);
		
		return _listCricketu.get(ID);
	}

	
	public Map<String, Cricket> get_listCricketu() {
		return _listCricketu;
	}

	public void set_List_Cricketu(Cricket cricket) {

		if (_listCricketu.containsKey(cricket.get_ID())) {
			/*
			System.out.println("Cricket : "
					+ cricket.get_ID()
					+ " "
					+ String.valueOf(_listCricketu.get(cricket.get_ID())
							.get_seznamDat().size()));
			//System.out.println("Cricket v databazi ");
*/
		} else {
			/*
			System.out.println("Cricket :" + cricket.get_ID()
					+ cricket.get_seznamDat().toString());
			*/
			_listCricketu.put(cricket.get_ID(), cricket);
			
			/*
			System.out.println(cricket.get_ID() + " " +cricket.get_XYsouradnic());
			System.out.println("Cricket do databaze pridan");
			*/
		}

	}

	public void Clear()
	{
		for(Cricket cricket : _listCricketu.values()){
			cricket.clear();
			
		}
		
	}
	
	public double get_DB(String ID, int index) {

		return _listCricketu.get(ID).get_seznamDat().get(index).get_Rssi();
	}

	public String ToString() {

		for (Map.Entry<String, Cricket> entry : _listCricketu.entrySet()) {
			System.out.println("Key = " + entry.getKey() + ", Value = "
					+ entry.getValue());
		}
		return "";
	}
	
	public Cricket getCricket(){
		return _cricket;
	}
	
	public void vypocetWCL() {
		double x = 0;
		double y = 0;
		double wij = 0;
		
		VypocetTrilaterace();
		
		for (Cricket cricket : _listCricketu.values()){
		//for (Map.Entry<String, Cricket> entry : _listCricketu.entrySet()) {
		//	if (!entry.getValue().equals(null)) {
			
			//entry.getValue().VypocetWCL();
			if(!cricket.getOld()){
			if (cricket.get_XYsouradnic() != null)
			{
			cricket.VypocetWCL();
			
			/*	
			 * x += entry.getValue().get_XYsouradnic().get_x();
				y += entry.getValue().get_XYsouradnic().get_y();
				wij += entry.getValue().get_wij();
				*/
			x += cricket.get_XYsouradnic().get_x();
			y += cricket.get_XYsouradnic().get_y();
			wij += cricket.get_wij();
			//System.out.println(x+" "+y+" "+wij);
			}
			}
		}
		
		x = x / wij;
		y = y / wij;
		//System.out.println("-------------"+x+" "+y );
		_XYsouradnice = new Koordinace(x, y);
		
		
	}

	public void VypocetTrilaterace(){
		int citac =0;
		int pocet = 0;
		// pro debug double[][] data = new double[3][3];
		
		for (Cricket cricket : _listCricketu.values()){
			if(!cricket.getOld()){
			pocet++;
			}
		}
		double[][] data = new double[pocet][3];
		for (Cricket cricket : _listCricketu.values()){
			
			if(!cricket.getOld()){
					if (cricket.getRSSI() != 0)
					{
					
						data[citac]= new double[]{cricket.get_XY_pozice_kotvy().get_x(),cricket.get_XY_pozice_kotvy().get_y(),cricket.getRSSI()};
						
						
						citac++;
					}
				}
			
		}
		
		
		
		/*
		data=new double[][]{{1,1,6.0415},{9,1,7.7782},{1,9,3.5355}};
		pocet = 3;
		citac = 3;
		Simulace P=[3.5,6.5] pro debug
		*/
			int max = citac-1;
			SimpleMatrix A;
			double[][] maticeA= new double[max][2];
			double[][] maticeB= new double[max][1];
			
			int i = 0;
			
			for (double[] a: data){
			if(i<data.length-1){
				maticeA[i] = new double[]{data[i][0]-data[max][0],data[i][1]-data[max][1]};
				
			}
				i++;
			
			}
			
		
			/*
			
			if (citac == 3) {
				maticeA = new double[][]{
						{data[0][0]-data[2][0],data[0][1]-data[2][1]},
						{data[1][0]-data[2][0],data[1][1]-data[2][1]}};
				
				
			}
			if (citac == 4) {
				int max = 3;
				maticeA = new double[][]{
						{data[0][0]-data[max][0],data[0][1]-data[max][1]},
						{data[1][0]-data[max][0],data[1][1]-data[max][1]},
						{data[2][0]-data[max][0],data[2][1]-data[max][1]}
						};
				
				 
				 
			}
			*/
			A = new SimpleMatrix(maticeA);
			A = A.scale(2);
			
			
			
			
			i=0;
			int j=0;
			for(double[] a :data){
				j=0;
				for(double b : a){
					data[i][j]=Math.pow(b, 2);
				j++;
				}
			i++;
			}
			
			SimpleMatrix B;
			i=0;
			for (double[] a: data){
				if(i<data.length-1)
					maticeB[i] =  new double[]{data[i][0] - data[max][0] + data[i][1] - data[max][1] + data[max][2] - data[i][2] };
					i++;
				
				}
				
			/*
			if (citac == 3) {
				maticeB = new double[][] {
						{ data[0][0] - data[2][0] + data[0][1] - data[2][1]	+ data[2][2] - data[0][2] },
						{ data[1][0] - data[2][0] + data[1][1] - data[2][1]	+ data[2][2] - data[1][2] } };
			
			}
			
			if (citac == 4) {
				int max = 3;
				maticeB = new double[][] {
						{ data[0][0] - data[max][0] + data[0][1] - data[max][1]	+ data[max][2] - data[0][2] },
						{ data[1][0] - data[max][0] + data[1][1] - data[max][1]	+ data[max][2] - data[1][2] },
						{ data[2][0] - data[max][0] + data[2][1] - data[max][1]	+ data[max][2] - data[2][2] } };
			
			}
			*/
			 B = new SimpleMatrix(maticeB);
			
			//Vypocet
			
			SimpleMatrix C = A.transpose();
			C = C.mult(A);
			SimpleMatrix D;
			C = C.invert();
			
			D = A.transpose();
			D = D.mult(B);
			
			
			SimpleMatrix P = new SimpleMatrix(C.mult(D));
			if(P.get(0)> 0){
			_XYTrilaterace = new Koordinace(P.get(0),P.get(1));
			}
		}
	//}
	
	
	
	public Koordinace get_XYsouradnice() {
		return _XYsouradnice;
	}
	public Koordinace get_XYTrilaterace() {
		return _XYTrilaterace;
	}
	 
	

	
	
}
